﻿/*
 * eRTK.h
 *
 * Created: 27.04.2015 13:38:51
 *  Author: er
 */ 
#ifndef ERTK_H_
#define ERTK_H_

#include <stddef.h>
#include <stdint.h>
#include "eRTK_config.h"
#include <../inc/Std_Types.h>


//der task control block
typedef struct { 
  void ( *task )( uint16 param0, void *param1 );
  uint8 prio;
  uint16 param0;
  void * param1;
 } t_eRTK_tcb;

extern const t_eRTK_tcb rom_tcb[NUMBER_OF_TASKS]; //das soll in der anwendung definiert sein

void __attribute__ ((naked)) eRTK_scheduler( void ); // start der hoechstprioren ready task, notfalls idle

//eRTK funktionsinterface
void      eRTK_init( void );                  //initialisieren der datenstrukturen
void      eRTK_timer_init( void );            //system timer initialisieren
void      eRTK_go( void );                    //start der hoechstprioren ready task, notfalls idle
uint8   eRTK_GetTimer8( void );             //systemzeit 1000Hz in 8 Bit
uint16  eRTK_GetTimer16( void );            //systemzeit 1000Hz in 16 Bit
eRTK_TYPE eRTK_GetTid( void );                //holen der eigenen task id
void      eRTK_SetReady( eRTK_TYPE tid );     //task fuer bereit erklaeren
void      eRTK_SetSuspended( eRTK_TYPE tid ); //task suspendieren
void      eRTK_WaitUntil( eRTK_TYPE then );   //warte auf den zeitpunkt
void      eRTK_Sleep_ms( uint16 ms );       //warte eine gewisse zeit
void      eRTK_get_sema( eRTK_TYPE semaid );  //Warten bis Semaphore frei ist und danach besetzen
void      eRTK_wefet( eRTK_TYPE timeout );    //Task suspendieren fuer eine gewisse zeit
//eRTK_cpri() setzen der prioritaet fuer eine task
//tid=0 setze die eigene prioritaet oder sonst die einer anderen task
//prio=neue prioritaet
//schedule_immediately wenn true dann wird sofort eine neue Prozesstabelle ermittelt und der hoechstpriore prozess gestartet
void eRTK_cpri( eRTK_TYPE tid, eRTK_TYPE prio, eRTK_TYPE schedule_immediately );

//gruende fuer einen toten bueffel
typedef enum { SYS_NOTASK, SYS_NULLPTR, SYS_NULLTIMER, SYS_OVERLOAD, SYS_VERIFY, SYS_STACKOVERFLOW, SYS_UNKNOWN } tsys;
	
//allgemeine fehlerbehandlung, kann je nach bedarf umgelenkt werden
void deadbeef( tsys reason );              //allgemeine fehler routine

#endif /* ERTK_H_ */
